import java.util.Arrays;

public class rotatebyone {
    public static void main(String[] args) {
        int a[] = {1,2,3,4,5};
        int l = a.length;
        int j = 0;

        for (int i = 1; i < l; i++) {

            int temp = a[i];
            a[i] = a[j];
            a[j] = temp;
            j++;
        }
        

        System.out.println(Arrays.toString(a));
        


    }
}
