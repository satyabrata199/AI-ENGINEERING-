import java.util.HashMap;

public class anagram {
    public static void main(String[] args) {
        String s2 = "abbc";
        String s1 = "bbba";

        

        var mp = new HashMap<Character,Integer>();

        if(s1.length() != s2.length())
        {
            System.out.println("not a valid anagram");
        }

        else
        {
           for(char c : s1.toCharArray())
           {
                mp.put(c,mp.getOrDefault(c, 0)+1);
           }

           for(char c : s2.toCharArray())
           {
                if(!mp.containsKey(c))
                {
                    System.out.println("not a valid Anagram");
                    break;
                }

                mp.put(c,mp.getOrDefault(c, 0)-1);

                if(mp.get(c) == 0)
                {
                    mp.remove(c);
                }
           }

           if(mp.isEmpty())
           {
            System.out.println("valid anagram");
           }
           else
           {
                System.out.println("not a valid anagram");
           }
        }


    }
}
