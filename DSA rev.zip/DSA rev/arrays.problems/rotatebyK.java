import java.util.Arrays;

public class rotatebyK {
    public static void main(String[] args) {
        int a[] = {1,2,3,4,5,6};

        int k = 3;

        int len = a.length;
        int l = 0 , r = len -1;

        while(l<=r)
        {
            int temp = a[l];
            a[l] = a[r];
            a[r] = temp;

            l++;
            r--;
        }

        System.out.println(l+" and "+r);
        System.out.println(Arrays.toString(a));
        

         l = 0;
         r = k - 1;
         while(l<=r)
         {
            int temp = a[l];
            a[l] = a[r];
            a[r] = temp;
            l++;
            r--;
         }

         System.out.println(Arrays.toString(a));

         l = k;
         r = len - 1;
         while(l<=r)
         {
            int temp = a[l];
            a[l] = a[r];
            a[r] = temp;
            l++;
            r--;
         }
         System.out.println(Arrays.toString(a));
    }
}
