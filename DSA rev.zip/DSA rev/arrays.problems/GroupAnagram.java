import java.util.*;
public class GroupAnagram {
    public static void main(String[] args) {
        String []ar = {"ate","eat","rat","tea","tar","silent","listen"};
        
        var mp = new HashMap<String,List<String>>();

        for(String s : ar)
        {
            char c[] = s.toCharArray();

            Arrays.sort(c);

            String key = new String(c);

            if(!mp.containsKey(key))
            {
                mp.put(key,new ArrayList<>());
            }
            mp.get(key).add(s);
        }

        System.out.println(mp);

    }

}
