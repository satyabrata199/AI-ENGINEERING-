import java.util.*;

public class rough {
    public static void main(String[] args) {
        var mp = new HashMap<String,Integer>();
        var set = new HashSet<String>();

        String n1 = "satya", n2 = "soam";
        mp.put(n1,101);
        mp.put(n2,202);

        System.out.println(mp.get(n1));
        System.out.println(mp.containsKey(n1));
    }
}
