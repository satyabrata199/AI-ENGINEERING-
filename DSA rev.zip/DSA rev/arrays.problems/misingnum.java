public class misingnum {
    public static void main(String[] args) {
        int a[] = {1,2,4,5};
        int l = a.length + 1;

        int totalSum = (l*(l+1))/2;
        int arSum = 0;
        for(int n:a)
        {
            arSum+=n;
        }

        System.out.println(totalSum - arSum);
    }
}
