"""
Call Analysis Pipeline
======================
1. Drop .mp3/.wav/.m4a files into  ./recordings/
2. Run:  python pipeline.py
3. Transcripts → ./transcripts/
4. Analysis JSON → ./analysis/

Requirements:
    pip install faster-whisper openai
    Set OPENAI_API_KEY env var (or paste below).
"""

import os
import json
import logging
from pathlib import Path

# ── Pricing (USD per 1M tokens) — update if OpenAI changes rates ──────────
PRICING = {
    "gpt-4o":            {"input": 2.50,  "output": 10.00},
    "gpt-4o-mini":       {"input": 0.15,  "output": 0.60},
    "gpt-5-mini":        {"input": 0.25,  "output": 2.00},
    "gpt-5":             {"input": 10.00, "output": 40.00},
    "gpt-4-turbo":       {"input": 10.00, "output": 30.00},
    "gpt-3.5-turbo":     {"input": 0.50,  "output": 1.50},
}

# Models that require max_completion_tokens instead of max_tokens
COMPLETION_TOKENS_MODELS = {"gpt-5-mini", "gpt-5", "o1", "o1-mini", "o3-mini"}

# Session-level accumulators
_session = {"calls": 0, "input_tokens": 0, "output_tokens": 0, "cost_usd": 0.0}

# ── Config ───────────────────────────────────────────────────────────────────
OPENAI_API_KEY  = os.getenv("OPENAI_API_KEY", "YOUR_OPENAI_API_KEY_HERE")
WHISPER_MODEL   = "large-v3"
OPENAI_MODEL    = "gpt-5-mini"
DEVICE          = "cuda"
COMPUTE_TYPE    = "float16"

RECORDINGS_DIR  = Path("recordings")
TRANSCRIPTS_DIR = Path("transcripts")
ANALYSIS_DIR    = Path("analysis")
LOGS_DIR        = Path("logs")

AUDIO_EXTENSIONS = {".mp3", ".wav", ".m4a", ".mp4", ".ogg", ".flac"}
# ─────────────────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(LOGS_DIR / "pipeline.log"),
    ]
)
log = logging.getLogger(__name__)


SYSTEM_PROMPT = """You are an expert call analyst specializing in debt settlement and debt consolidation sales calls. Listen to this phone call recording with extreme attention to detail.

## Speaker identification
- AGENT: the debt settlement/consolidation sales representative
- CUSTOMER: the person with debt seeking help

## Your task
Extract EVERY piece of information mentioned in the call. Capture specific numbers, creditor names, balances, interest rates, monthly payments, and settlement terms exactly as spoken. These calls are high-value — every dollar amount and creditor name matters for enrollment processing.

Pay special attention to:
- Every creditor/account mentioned — name, balance, interest rate, monthly payment, account status
- Total debt figures — current total, projected settlement total, savings
- Monthly payment discussions — current total payments vs proposed program payment
- Timeline discussions — program length, when settlements happen
- Customer's financial hardship — what caused the debt, income situation, ability to pay
- Objections and concerns — interest in the program, skepticism, competing offers
- Compliance language — disclosures, disclaimers, authorization language
- Emotional state — stress level, urgency, relief, hesitation

## Output format

Return a JSON object with the following structure. Include ALL sections — use null for fields not discussed, empty arrays [] where no items exist. Do NOT remove sections.

{
  "call_summary": {
    "overview": "2-3 sentence summary of the call — who called, what was discussed, outcome",
    "company_name": "debt settlement/consolidation company name",
    "agent_name": "agent's name if stated",
    "call_type": "inbound | outbound | transfer | follow_up",
    "call_purpose": "initial consultation | follow_up | enrollment | objection_handling | verification",
    "call_outcome": "enrolled | scheduled_callback | declined | needs_time | transferred | dropped",
    "call_duration_seconds": null,
    "language": "English",
    "customer_sentiment": "positive | neutral | negative | mixed | stressed | relieved",
    "call_quality": "completed | dropped | incomplete | transferred"
  },
  "customer_profile": {
    "name": "full name if given",
    "state": "US state",
    "city": "if mentioned",
    "phone": "if mentioned",
    "email": "if mentioned",
    "age": null,
    "gender": "male | female | unknown",
    "employment_status": "employed | self_employed | unemployed | retired | disabled",
    "employer": "if mentioned",
    "monthly_income": "gross or net as stated",
    "household_size": null,
    "homeowner": "yes | no | renting | null",
    "has_checking_account": null,
    "bank_name": "if mentioned"
  },
  "debt_profile": {
    "total_unsecured_debt": "exact total as stated by agent or customer",
    "number_of_accounts": null,
    "accounts": [
      {
        "creditor": "exact creditor/bank name",
        "account_type": "credit_card | personal_loan | medical | store_card | other",
        "balance": "current balance",
        "interest_rate": "if mentioned",
        "monthly_payment": "current minimum payment",
        "months_behind": "if delinquent",
        "in_collections": false,
        "last_payment_date": null,
        "notes": "any additional detail about this account"
      }
    ],
    "excluded_debts": [],
    "hardship_reason": "what caused the debt situation",
    "hardship_details": "specific details about the hardship"
  },
  "current_payments": {
    "total_monthly_minimums": "sum of all minimum payments currently",
    "can_afford_minimums": "yes | no | barely",
    "missed_payments": "how many accounts are behind, how far behind",
    "collection_calls": "yes | no | null"
  },
  "program_offered": {
    "program_type": "debt_settlement | debt_consolidation | debt_management | bankruptcy_alternative",
    "estimated_settlement_percentage": "what % of debt they expect to settle at",
    "estimated_total_settlement": "projected total amount to pay back",
    "estimated_savings": "projected savings vs paying full balances",
    "monthly_program_payment": "proposed monthly deposit",
    "program_length_months": "estimated program duration",
    "fees": {
      "enrollment_fee": null,
      "monthly_service_fee": null,
      "settlement_fee_percentage": "% charged per settled account",
      "total_estimated_fees": null
    },
    "escrow_account": "where deposits go",
    "first_payment_date": "when first deposit is due",
    "creditor_communication": "yes | no"
  },
  "settlement_projections": [],
  "customer_objections": [],
  "competitor_mentions": [],
  "compliance_and_disclosures": {
    "company_disclosed": "yes | no",
    "recording_disclosure": "yes | no | unclear",
    "no_guarantee_disclosure": "yes | no",
    "credit_impact_disclosure": "yes | no",
    "tax_implications_mentioned": "yes | no",
    "right_to_cancel": "yes | no",
    "authorization_obtained": "yes | no | pending",
    "power_of_attorney": "yes | no",
    "state_specific_disclosures": null
  },
  "verification_info": {
    "identity_verified": null,
    "last_4_ssn": null,
    "date_of_birth": null,
    "address_confirmed": null,
    "email_confirmed": null
  },
  "agent_performance": {
    "greeting_quality": "proper | informal | missing | rushed",
    "rapport_building": null,
    "needs_assessment": "thorough | adequate | rushed | missed_key_info",
    "objection_handling": "effective | adequate | poor | aggressive | empathetic",
    "urgency_creation": "appropriate | excessive | fear_based | none",
    "closing_technique": "assumptive | consultative | pressure | soft | none",
    "compliance_adherence": "all disclosures made | some missing | major gaps",
    "promises_made": [],
    "red_flags": []
  },
  "qa_scorecard": {
    "total_score": 0,
    "categories": {
      "call_opening": {
        "max_score": 7.5,
        "scored": 0,
        "items": [
          {"criterion": "Agent opened the call on correct time (< 5 sec)", "max": 2.5, "score": 0, "evidence": ""},
          {"criterion": "Agent gave proper call opening with branding", "max": 2.5, "score": 0, "evidence": ""},
          {"criterion": "Agent gave greetings and addressed the customer", "max": 2.5, "score": 0, "evidence": ""}
        ]
      },
      "probing_and_resources": {
        "max_score": 5.0,
        "scored": 0,
        "items": [
          {"criterion": "Agent confirmed the debt, decision maker, and current monthly payment status", "max": 2.5, "score": 0, "evidence": ""},
          {"criterion": "Agent confirmed the reason of hardship", "max": 2.5, "score": 0, "evidence": ""}
        ]
      },
      "features_and_benefits": {
        "max_score": 40.0,
        "scored": 0,
        "items": [
          {"criterion": "Agent explained the program benefits", "max": 2.5, "score": 0, "evidence": ""},
          {"criterion": "Agent took and confirmed DOB and last 4 of Social Security", "max": 3.75, "score": 0, "evidence": ""},
          {"criterion": "Agent was able to handle and answer customer's objections properly", "max": 3.75, "score": 0, "evidence": ""},
          {"criterion": "Agent used proper pitch for credit pull and authorization", "max": 2.5, "score": 0, "evidence": ""},
          {"criterion": "Agent took authorization for credit check", "max": 7.5, "score": 0, "evidence": ""},
          {"criterion": "Agent was able to verbally share credit report details with customer", "max": 2.5, "score": 0, "evidence": ""},
          {"criterion": "Agent explained the program properly", "max": 5.0, "score": 0, "evidence": ""},
          {"criterion": "Agent designed the program and offered a payment plan as per customer's situation", "max": 5.0, "score": 0, "evidence": ""},
          {"criterion": "Agent proactively did NOT inform about payment date change", "max": 5.0, "score": 0, "evidence": ""},
          {"criterion": "Agent explained to customer about card close", "max": 2.5, "score": 0, "evidence": ""}
        ]
      },
      "call_handling": {
        "max_score": 22.5,
        "scored": 0,
        "items": [
          {"criterion": "Agent used the statement 'take conscious decision to no longer pay minimum payments'", "max": 5.0, "score": 0, "evidence": ""},
          {"criterion": "Agent did NOT discuss credit repair or better score", "max": 5.0, "score": 0, "evidence": ""},
          {"criterion": "Agent handled all rebuttals when required", "max": 2.5, "score": 0, "evidence": ""},
          {"criterion": "Agent was active over the call", "max": 2.5, "score": 0, "evidence": ""},
          {"criterion": "Agent was professional throughout the call", "max": 5.0, "score": 0, "evidence": ""},
          {"criterion": "Agent was easy to understand", "max": 2.5, "score": 0, "evidence": ""}
        ]
      },
      "customization": {
        "max_score": 5.0,
        "scored": 0,
        "items": [
          {"criterion": "Agent conducted budget analysis", "max": 2.5, "score": 0, "evidence": ""},
          {"criterion": "Agent confirmed the reason of hardship", "max": 2.5, "score": 0, "evidence": ""}
        ]
      },
      "e_contract": {
        "max_score": 7.5,
        "scored": 0,
        "items": [
          {"criterion": "Agent assisted the customer to sign the contract step by step", "max": 2.5, "score": 0, "evidence": ""},
          {"criterion": "Agent did NOT coach the customer for welcome/QC call", "max": 5.0, "score": 0, "evidence": ""}
        ]
      },
      "mandatory_disclosure": {
        "max_score": 12.5,
        "scored": 0,
        "items": [
          {"criterion": "Agent covered all mandatory disclosures with explaining all points", "max": 12.5, "score": 0, "evidence": ""}
        ]
      }
    }
  },
  "next_steps": [],
  "additional_notes": []
}

## QA scoring rules
- Score each item based ONLY on what you see in the transcript.
- For YES/NO items: full marks if clearly done, 0 if not done or unclear.
- For NEGATIVE items: full marks if agent did NOT do the thing.
- Always provide evidence for each score.

Return ONLY valid JSON. No markdown fences, no preamble, no commentary."""


def transcribe(audio_path: Path) -> str:
    """Transcribe audio using faster-whisper."""
    from faster_whisper import WhisperModel

    log.info(f"Loading Whisper {WHISPER_MODEL} on {DEVICE} ...")
    model = WhisperModel(WHISPER_MODEL, device=DEVICE, compute_type=COMPUTE_TYPE)

    log.info(f"Transcribing: {audio_path.name}")
    segments, info = model.transcribe(str(audio_path), beam_size=5, language="en")

    lines = []
    for seg in segments:
        ts = f"[{seg.start:.1f}s - {seg.end:.1f}s]"
        lines.append(f"{ts} {seg.text.strip()}")

    transcript = "\n".join(lines)
    log.info(f"Transcription done — {info.duration:.0f}s audio, {len(lines)} segments")
    return transcript


def _calc_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """Return cost in USD for a single API call."""
    rates = PRICING.get(model, PRICING["gpt-4o"])
    return (input_tokens * rates["input"] + output_tokens * rates["output"]) / 1_000_000


def analyze(transcript: str, filename: str) -> dict:
    """Send transcript to OpenAI and get structured JSON analysis."""
    from openai import OpenAI

    client = OpenAI(api_key=OPENAI_API_KEY)

    log.info(f"Sending to OpenAI ({OPENAI_MODEL}) for analysis ...")

    # gpt-5-mini and o-series models use max_completion_tokens, not max_tokens
    token_param = "max_completion_tokens" if OPENAI_MODEL in COMPLETION_TOKENS_MODELS else "max_tokens"

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": f"Filename: {filename}\n\nTranscript:\n{transcript}"}
        ],
        temperature=0,
        **{token_param: 4096},
    )

    # ── Token usage & cost ────────────────────────────────────────────────
    usage      = response.usage
    input_tok  = usage.prompt_tokens
    output_tok = usage.completion_tokens
    total_tok  = usage.total_tokens
    cost       = _calc_cost(OPENAI_MODEL, input_tok, output_tok)

    _session["calls"]         += 1
    _session["input_tokens"]  += input_tok
    _session["output_tokens"] += output_tok
    _session["cost_usd"]      += cost

    log.info(
        f"\n  ┌─ Cost for this call ──────────────────────\n"
        f"  │  Model        : {OPENAI_MODEL}\n"
        f"  │  Input tokens : {input_tok:,}\n"
        f"  │  Output tokens: {output_tok:,}\n"
        f"  │  Total tokens : {total_tok:,}\n"
        f"  └─ Cost         : ${cost:.4f} USD"
    )
    # ─────────────────────────────────────────────────────────────────────

    raw = response.choices[0].message.content.strip()

    # Strip accidental markdown fences
    if raw.startswith("```"):
        raw = raw.split("```", 2)[1]
        if raw.startswith("json"):
            raw = raw[4:]

    return json.loads(raw)


def process_file(audio_path: Path):
    stem            = audio_path.stem
    transcript_path = TRANSCRIPTS_DIR / f"{stem}.txt"
    analysis_path   = ANALYSIS_DIR    / f"{stem}.json"

    if analysis_path.exists():
        log.info(f"Skipping {audio_path.name} — analysis already exists")
        return

    # Step 1: Transcribe (or load cached)
    if transcript_path.exists():
        log.info(f"Using cached transcript: {transcript_path.name}")
        transcript = transcript_path.read_text(encoding="utf-8")
    else:
        transcript = transcribe(audio_path)
        transcript_path.write_text(transcript, encoding="utf-8")
        log.info(f"Saved transcript → {transcript_path}")

    # Step 2: Analyze
    result = analyze(transcript, audio_path.name)

    analysis_path.write_text(
        json.dumps(result, indent=2, ensure_ascii=False),
        encoding="utf-8"
    )
    log.info(f"Saved analysis  → {analysis_path}")


def run():
    for d in [RECORDINGS_DIR, TRANSCRIPTS_DIR, ANALYSIS_DIR, LOGS_DIR]:
        d.mkdir(exist_ok=True)

    audio_files = [
        f for f in RECORDINGS_DIR.iterdir()
        if f.suffix.lower() in AUDIO_EXTENSIONS
    ]

    if not audio_files:
        log.warning(f"No audio files found in ./{RECORDINGS_DIR}/")
        log.warning("Drop .mp3 / .wav / .m4a files there and re-run.")
        return

    log.info(f"Found {len(audio_files)} file(s) to process")

    for audio_path in sorted(audio_files):
        try:
            process_file(audio_path)
        except Exception as e:
            log.error(f"Failed on {audio_path.name}: {e}", exc_info=True)

    log.info("Pipeline complete.")

    # ── Session cost summary ──────────────────────────────────────────────
    if _session["calls"] > 0:
        log.info(
            f"\n  ╔══ Session Summary ════════════════════════╗\n"
            f"  ║  Calls analyzed   : {_session['calls']}\n"
            f"  ║  Total input tok  : {_session['input_tokens']:,}\n"
            f"  ║  Total output tok : {_session['output_tokens']:,}\n"
            f"  ║  Total tokens     : {_session['input_tokens'] + _session['output_tokens']:,}\n"
            f"  ╠═══════════════════════════════════════════╣\n"
            f"  ║  TOTAL COST       : ${_session['cost_usd']:.4f} USD\n"
            f"  ║  Avg per call     : ${_session['cost_usd'] / _session['calls']:.4f} USD\n"
            f"  ╚═══════════════════════════════════════════╝"
        )


if __name__ == "__main__":
    run()
