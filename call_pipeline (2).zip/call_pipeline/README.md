# Call Analysis Pipeline

Transcribes call recordings with **faster-whisper large-v3**, then extracts structured
debt-settlement call data via **GPT-4o**.

---

## Folder structure

```
call_pipeline/
├── pipeline.py          ← main script
├── requirements.txt
├── recordings/          ← DROP YOUR AUDIO FILES HERE
├── transcripts/         ← auto-generated .txt transcripts
├── analysis/            ← auto-generated .json analysis files
└── logs/                ← pipeline.log
```

---

## Setup (one time)

```bash
cd call_pipeline

# Install dependencies
pip install -r requirements.txt

# Set your OpenAI API key
export OPENAI_API_KEY="sk-..."
```

> **GPU?**  Edit `pipeline.py` → set `DEVICE = "cuda"` and `COMPUTE_TYPE = "float16"` for 5-10× faster transcription.

---

## Run

```bash
# 1. Drop recordings into ./recordings/
#    Supported: .mp3  .wav  .m4a  .mp4  .ogg  .flac

# 2. Run
python pipeline.py
```

That's it. For each file you'll get:
- `transcripts/<filename>.txt`  — timestamped transcript
- `analysis/<filename>.json`    — full structured analysis + QA scorecard

Already-processed files are **skipped automatically** on re-runs.

---

## Tips

- **Only have a transcript already?**  Just drop the `.txt` into `transcripts/` with the same base name as a dummy audio file in `recordings/` — the pipeline will use it and skip re-transcribing.
- **Batch mode** — drop as many files as you want; the pipeline processes them all in sequence.
- **Logs** — check `logs/pipeline.log` for details on each run.
